﻿namespace FirstShuter
{
	public interface ICollision
	{
		void OnCollision(InfoCollision info);
	}
}