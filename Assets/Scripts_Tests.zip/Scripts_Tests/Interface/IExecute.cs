﻿namespace Geekbrains
{
    public interface IExecute
    {
        void Execute();
    }
}
