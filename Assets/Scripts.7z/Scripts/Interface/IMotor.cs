﻿namespace FirstShuter
{
	public interface IMotor
	{
		void Move();
	}
}