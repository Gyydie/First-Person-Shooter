﻿namespace FirstShuter
{
	public interface IInitialization
	{
		void Initialization();
	}
}