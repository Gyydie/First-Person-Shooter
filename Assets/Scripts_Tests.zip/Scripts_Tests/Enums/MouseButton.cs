﻿namespace Geekbrains
{
	public enum MouseButton : byte
	{
		None        = byte.MaxValue,
		LeftButton  = 0,
		RightButton = 1
	}
}