﻿namespace FirstShuter
{
    public static class TagManager
    {
        public const string PLAYER = "Player";
    }
}
