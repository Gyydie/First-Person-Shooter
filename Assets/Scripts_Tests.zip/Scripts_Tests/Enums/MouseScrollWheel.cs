﻿namespace Geekbrains
{
    public enum MouseScrollWheel : byte
    {
        None = 0,
        Down = 1,
        Up   = 2
    }
}
