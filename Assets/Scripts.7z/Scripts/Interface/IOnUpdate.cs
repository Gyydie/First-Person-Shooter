﻿namespace FirstShuter
{
	public interface IOnUpdate
	{
		void OnUpdate();
	}
}