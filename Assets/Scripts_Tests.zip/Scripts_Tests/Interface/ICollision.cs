﻿namespace Geekbrains
{
	public interface ICollision
	{
		void OnCollision(InfoCollision info);
	}
}