﻿namespace Geekbrains
{
    public static class TagManager
    {
        public const string PLAYER = "Player";
    }
}
