﻿namespace Geekbrains
{
	public interface IInitialization
	{
		void Initialization();
	}
}