﻿namespace Geekbrains
{
    public enum StateBot
    {
        None       = 0,
        Patrol     = 1,
        Inspection = 2,
        Detected   = 3,
        Died       = 4
    }
}
