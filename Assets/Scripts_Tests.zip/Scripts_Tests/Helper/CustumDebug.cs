﻿using UnityEngine;

namespace Geekbrains
{
    public static class CustumDebug 
    {
        public static void Log(object value)
        {
            Debug.Log(value);
        }
    }
}
