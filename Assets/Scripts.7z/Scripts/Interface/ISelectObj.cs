﻿namespace FirstShuter
{
	public interface ISelectObj
	{
		string GetMessage();
	}
}