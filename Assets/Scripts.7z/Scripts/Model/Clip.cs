﻿namespace FirstShuter
{
    public struct Clip
    {
        public int CountAmmunition;
    }
}
