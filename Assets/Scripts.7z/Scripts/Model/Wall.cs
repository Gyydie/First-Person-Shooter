﻿namespace FirstShuter
{
	public sealed class Wall : BaseObjectScene, ISelectObj
	{
		public string GetMessage()
		{
			return Name;
		}
	}
}