﻿namespace FirstShuter
{
    public interface IExecute
    {
        void Execute();
    }
}
