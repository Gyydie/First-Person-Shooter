﻿using UnityEngine;


namespace FirstShuter
{
    class RestoreBattaryCharge : BaseObjectScene
    {
        //    [SerializeField] private float _batteryChargeMax = 100f;
        //    private FlashLightModel _flashLightModel;


        //    public void RestoreBattary()
        //    {
        //        _flashLightModel.BatteryChargeCurrent = _batteryChargeMax;
        //        return;
        //    }

        //    private void OnTriggerEnter(Collider other)
        //    {
        //        if (gameObject.CompareTag(TagManager.PLAYER))
        //        {
        //            RestoreBattary();
        //        }
        //    }
    }
}
