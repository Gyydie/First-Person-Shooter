﻿namespace FirstShuter
{
	public enum AmmunitionType
	{
		None   = 0,
		Rpg    = 2,
		Bullet = 4,
		Laser  = 6
	}
}