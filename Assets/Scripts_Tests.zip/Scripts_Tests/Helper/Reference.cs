﻿using UnityEngine;


namespace Geekbrains
{
    public sealed class Reference : MonoBehaviour
    {
        public Bot Bot;
    }
}
