﻿using UnityEngine;


namespace FirstShuter
{
    public sealed class Reference : MonoBehaviour
    {
        public Bot Bot;
    }
}
